package com.itlf.kaoshi.dao;

import com.itlf.kaoshi.pojo.User;

/**
 * @Author LiuFeng
 * @Date 2020/9/29 19:01
 */
public interface UserDao {
    User login(User user);
}
